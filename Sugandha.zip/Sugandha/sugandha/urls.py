"""
URL configuration for sugandha project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from sugandha import view
from django.utils.text import slugify

urlpatterns = [
    path('admin/', admin.site.urls),
    path('apt/',view.homepage),
    path('apt1/',view.localvariable),
    path('apt2/',view.globalvariable),
    path('apt3/',view.form),
    path('apt4/',view.Add),
    path('apt5/',view.Swap),
    path('apt6/',view.login),
    path('apt7/',view.BigNumber),
    path('apt8/',view.atm_transaction),
    path('apt9/',view.check_grade),
    path('apt10/',view.table),
    path('apt11/',view.list),
    path('apt12/',view.student),
    path('apt13/',view.for1),
    path('apt14/',view.squared_numbers_view),
    path('apt15/',view.even_numbers),
    path('apt16/',view.manipulate_string_view),
    path('apt17/',view.images),
    path('apt18/',view.logo1),
    path('apt19/',view.Restaurant,name='Restaurant'),
    path('apt120/',view.page1,name='page1'),
    path('apt21/',view.contect , name='contect'),
    path('food/',view.project ,name='prject'),
    path('food2/',view.menu ,name='menu'),
    path('food4/',view.menu1 ,name='menu1'),
    path('food3/',view.loginpage,name='loginpage'),
    path('database/',view.value),
    path('set/',view.setcookie),
    path('get/',view.getcookie),
    path('session/',view.homepageses),
    path('session1/',view.index1),
    path('session2/',view.counter_view,name='counter_view'),
    path('wrong/',view.wrong),
    path('food01/',view.project01 ,name='login'),
    #--------------------------------online food ordering system------------------------------------
    path('food001/',view.project001 ,name='signin'),
    path('food002/',view.project002 ,name='signup'),
    path('food003/',view.project003 ,name='signinpage'),
    path('food02/',view.project02 ,name='MainPage'),
    path('food03/',view.project03 ,name='About'),
    path('food04/',view.project04 ,name='nonveg'),
    path('food05/',view.project05 ,name='VegThali'),
    path('food06/',view.project06 ,name='soup'),
    path('food07/',view.project07 ,name='sweet'),
    path('food08/',view.project08 ,name='order'),
    path('food09/',view.project09 ,name='contact'),
    #--------------------------------------------------------------------------------------------------------
    path('lcm/',view.lcm_calculator),
    path('vowel/',view.vowel_counter),
    path('perfect/',view.perfect_number),
    path('recursion/',view.factorial),
    path('str1/',view.string_length),
    #-------------------------------------------------
    path('slug/<int:sid>/',view.slug1,name='slug_temp'),
    path('pages/<slug:slug>/',view.slug2,name='slug2_temp'),
    path('create/', view.create_article, name='create_article'),
    path('reverse/', view.reverse,name='reverse_text'),
    path('replace/', view.replace_word),
    path('concate/', view.concatenate_strings_view),
    path('largestarray/', view.find_first_largest_smallest),
    path('push/', view.array_push),
    

]

