from django.shortcuts import render
from django.utils.text import slugify
def homepage(request):
    return render(request,'welcome.html')
def localvariable(request):
    my_variable='Hello World'
    return render(request,'local1.html',{'my_variable':my_variable})
def globalvariable(request):
    return render(request,'global.html',{'my_variable':"welcome python"})
def form(request):
    return render(request,'form.html')
def Add(request):
    if request.method =='POST':
        num1=int(request.POST.get('num1'))
        num2=int(request.POST.get('num2'))
        result=num1+num2
        return render(request,'outAdd.html',{'result':result})
    return render(request,'Add.html')
def Swap(request):
    if request.method =='POST':
        num1=int(request.POST.get('num1'))
        num2=int(request.POST.get('num2'))
        num1 = num1 + num2    
        num2 = num1 - num2   
        num1 = num1 - num2  
        return render(request,'swap_out.html',{'num1':num1,'num2':num2})
    return render(request,'swap.html')

def login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        if username=='admin'  and password=='password':
            return render(request,'success.html',{'username':username})
        else:
            error='Invalid username or passwor . Please try again.'
            return render(request,'login_form.html',{'error':error})
    return render(request,'login_form.html')
def BigNumber(request):
    if request.method =='POST':
        a=int(request.POST.get('Number1'))
        b=int(request.POST.get('Number2'))
        if a>b:
          return render(request,'bignumout.html',{'number':'a is grater than b'})
        else:
         b='b is grater than a'
         return render(request,'bignumout.html',{'number':b})
    return render(request,'Biggest.html')

def atm_transaction(request):
    balance = 1000
    #limit=500
    if request.method == 'POST':
     transaction_type=request.POST.get('transaction_type')   #w
     amount=int(request.POST.get('amount')) #1200
     if(transaction_type=='check_balance'):
         message= balance
     elif(transaction_type=='deposit'):
         message=amount+balance
     elif(transaction_type=='withdraw'): 
         # if(amount<=limit):
             # message='limit'

              if(amount%100==0):#239%100==0
               if(balance>amount):#1000>2000
                  message=balance-amount
               else:
                 message="overdraft"
              else:
                message="multiple of 100"
     return render(request, 'success1.html', {'message': message})
    

    return render(request, 'Atm_tranjection.html')

def check_grade(request):
    if request.method=='POST':
        name=request.POST.get('name')
        marks1=int(request.POST.get('marks1'))
        marks2=int(request.POST.get('marks2'))
        marks3=int(request.POST.get('marks3'))

        total=marks1+marks2+marks3
        avg=(marks1+marks2+marks3)/3

        if (avg>95 and avg<100):
            grade='A grade'
        elif(avg>75 and avg<95):
            grade='B grade'
        elif(avg>50 and avg<75):
            grade='c grade'
        else:
            grade='fail'

            return render(request, 'success3.html', {'name':name,'total':total, 'average':avg ,'grade':grade})
    

    return render(request, 'Grade.html')

def table(request):
    data=[
        {'name':'apna','age':29},
        {'name':'priyanka','age':23},
        {'name':'Abhi','age':25},
        {'name':'Rupesh','age':24},
    ]
    return render(request,'table.html',{'data':data})

def list(request):
    l1=['Banglore','supaul','puna']
    return render(request,'list.html',{'items':l1})

def student(request):
    students=[
        {'name':'Rupesh','math':70, 'science':80,'english':75},
        {'name':'Sugandha','math':60, 'science':70,'english':70},
        {'name':'Priyanka','math':60, 'science':70,'english':70},
        {'name':'Rohit','math':65, 'science':73,'english':73}
    ]
    return render(request,'dict.html',{'stu':students})

def for1(request):
    list1=['APT','BTM','Banglore']
    list2=['Apteknow','jaynagar','banglore']

   # list1,list2=list2,list1
    list1[1],list2[1]=list2[1],list1[1]

    return render(request,'for2.html',{'list1':list1,'list2':list2})

def squared_numbers_view(request):
    numbers=[1,2,3,4,5]
    squared_number=[num ** 2 for num in numbers]
    context={'squared_number':squared_number}
    return render(request, 'squared_number.html',context)

def even_numbers(request):
    numbers=[i*2 for i in range(1,11) if i%2==0]
    total=sum(numbers)
    Avg=total/len(numbers)
    return render(request, 'even_number.html',{'numbers':numbers ,'total':total,'avg':Avg})

def manipulate_string_view(request):
    names=['apt', 'btm', 'india']
    uppercase_names=[name.upper() for name in names]
    data={'uppercase_names':uppercase_names}
    return render(request, 'manipulated_string.html', data)

def images(request):
    return render(request,'image.html')
            
def logo1(request):
    return render(request,'logo1.html')

def Restaurant(request):
    return render(request,'Restaurant.html')
            

def page1(request):
    return render(request,'page1.html')



def project(request):
    return render(request,'Project.html')
        
def loginpage(request):
    return render(request,'loginpage.html')

def contect(request):
    return render(request,'contect_us.html')

def menu(request):
    return render(request,'menu.html')
def menu1(request):
    return render(request,'menu1.html')

from result.models import *
def value(request):
    if request.method=="POST":       
        a= request.POST.get('name')
        b= request.POST.get('email')
        c= request.POST.get('phone')
        en=Enquiry(name=a,email=b,phone=c)
        en.save()
    return render(request,"login1.html")

def setcookie(request):
     response=render(request,'setcookie.html')
     response.set_cookie('Name','Banglore')
     return response

def getcookie(request):
    Name=request.COOKIES['Name']
    return render(request,'getcookie.html',{'name':Name})

def homepageses(request):
    visit_count=request.session.get('visit_count',0)
    visit_count+=1
    request.session['visit_count']=visit_count

    return render(request,'homepage.html',{'visit_count':visit_count})

def index1(request):
    visited=request.session.get('visited', False)
    if visited:
        message="Welcome back"
    else:
        message='welcome to my site!'
        request.session['visited']=True
    return render(request,'index1.html',{'message':message})

def counter_view(request):
    count=request.session.get('couunt',0)
    if 'increment' in request.POST:
        count+= 1
    elif 'decrement' in request.POST:
        count=max(0, count - 1)
    elif 'reset' in request.POST:
        count=0
        request.session['count']=count
    return render(request,'counter.html',{'count':count})



# def exception(request):
#     if request.method =='POST':
#      try:
#          num1=int(request.POST.get('num1'))
#          num2=int(request.POST.get('num2'))
    

#          operation=request.POST.get('operation')

#        if operation=='add':
#         result=num1 +num2

#        elif operation=='subtract':
#         result=num1-num2
#         elif operation=='multiplay':
#         result=num1*num2

#      elif operation=='divide':
#         if num2==0:
#             raise ZeroDivisionError("cannot divide by zero")
#         result=num1/num2

#      return render(request, 'exception.html' {'result':result str(0)})

       
#      except (ZeroDivisionError) as a:

#    return render(request,'exception.html',('error_message': result str(0)))

# return render(request,'exception.html')

# def arraybound(request):
#     my_arry= [20,40,,50,60]
# try:
#     index=int(request.GET.get('index',1))
#     element=my_array[index]
# except (ValueError,IndexError):
#     element=None
# return render(request,'index.html'{'element':element})

def wrong(request):
    if request.method=='POST':
        try:
            value=int(request.POST.get('value'))
        except ValueError:
             value=None 
        return render(request,'my_template.html',{'value':value})
    return render(request,'my_template.html')   

def project01(request):
    return render(request,'login.html')


#--------------------------Online food ordering system--------------------------------------------------------

def project001(request):
    return render(request,'signin.html')

def project002(request):
    return render(request,'signup.html')

def project003(request):
    return render(request,'signinpage.html')

def project02(request):
    return render(request,'MainPage.html')

def project03(request):
    return render(request,'About.html')

def project04(request):
    return render(request,'nonveg.html')

def project05(request):
    return render(request,'VegThali.html')

def project06(request):
    return render(request,'soup.html')

def project07(request):
    return render(request,'sweet.html')

def project08(request):
    return render(request,'order.html')

def project09(request):
    return render(request,'contact.html')

#----------------------------------------------------------------------------------------------------

def lcm_calculator(request):
    context = {}
    if request.method == 'POST':
        num1 = int(request.POST.get('num1'))#2
        num2 = int(request.POST.get('num2'))#3
        result = calculate_lcm(num1, num2)# 2,3  6
        context['result'] = result  # 6
    return render(request, 'lcm.html', context)

def calculate_lcm(a, b):#2#3
    multiple = max(a, b)# 2, 3   3
    while True:  #   
        if multiple % a == 0 and multiple % b == 0:#     6%2==0 and 6%3==0:
            return multiple  #6
        multiple += 1


def vowel_counter(request):
    context={}
    if request.method=='POST':
        text=request.POST.get('text','')
        vowel_count=count_vowels(text)
        context['vowel_count']=vowel_count
    return render(request,'vowel_cons.html',context)

def count_vowels(text):
    vowels='AEIOUaeiou'
    count=' '
    for char in text:          
        if char in  vowels:       #for vowels char return
            count+=char
    return count

def count_vowels(text):
    vowels='AEIOUaeiou'
    count=0
    for char in text:          
        if char in  vowels:       #for vowels count return
            count+=1
    return count

def count_vowels(text):
    vowels='AEIOUaeiou'
    count=0
    for char in text:          
        if char not in  vowels:       #for consanent count return
            count+=1
    return count
#-----------------------------------

def perfect_number(request):
    context={}
    if request.method=='POST':

        number=int(request.POST.get('number'))#6
        is_perfect=check_perfect(number)#6
        context['number']=number

        context['is_perfect']= is_perfect
    return render(request,'perfectno.html',context)
    

def check_perfect(number):
    divisor_sum=0
    for i in range(1,number):#6<6

        if number%i == 0:
          divisor_sum += i #0+1=1+2=3+3=6

    return divisor_sum == number
    
    #--------------------------------------------

def factorial(request):
    if request.method=='POST':
        num=int(request.POST.get('number'))
        
        def calculate_factorial(n):

            if n==0:
                return 1
            else:
                return n*calculate_factorial(n-1)
        result=calculate_factorial(num)
        return render(request,'recursion_function.html',{'result':result})
    return render(request,'recursion_function.html')

#-----------------------------
def calculate_string_length(string): # bangalore
    count=0
    for ch in string:
        count+=1 #9
    return count

def string_length(request):

    string_length=None

    if request.method == 'POST':

     user_input=request.POST.get('user_input','') # bangalore
     string_length=calculate_string_length(user_input) # bangalore
    context={'string_length':string_length}
    return render(request,'lenstr.html',context)
#------------------------------------------------
def slug1(request,sid):
    return render(request,'slug_temp.html',{'sid':sid})

def slug2(request,slug):
    data={
        'title':'page details',
        'content':f'this is the details  page for {slug}',
    }

    return render(request,'slug2_temp.html',data)


def create_article(request):
    if request.method == 'POST':
        title=request.POST.get('title','')
        slug=slugify(title)
        return render(request,'slug_result.html',{'title':title,'slug':slug})
    return render(request,'create_article.html')

def reverse(request):
    reversed_text=""
    if request.method=='POST':
        text=request.POST.get('input_text')
        reversed_text=text[::-1]
    return render(request,'reverse_text.html',{'reversed_text':reversed_text})
#--------------------------------------
def replace_word(request):

    replaced_text=""
    if request.method=='POST':

      text=request.POST.get('input_text','')
      old_word=request.POST.get('old_word','')

      new_word=request.POST.get('new_word','')

      replaced_text=text.replace( old_word,new_word)

    return render(request,'replace.html',{'replaced_text': replaced_text})


# def string_length_view(request,input_string):
#     input_string='banglore'
#     length=len(input_string)

#     return HttpResponse(f"The length of string'{input_string} is {length}.")

def concatenate_strings_view(request):
    result=""
    if request.method=='POST':
        str1=request.POST.get('str1','')

        str2=request.POST.get('str2','')
        result=str1+str2
    return render(request,'concatenate_strings1.html',{'result':result})


def find_first_largest_smallest(request):
    smallest=None
    largest=None
    if request.method=='POST':
       numbers_str=request.POST.get('numbers','')#"324567"
       numbers=[int(num.strip()) for num in numbers_str.split(',')if num.strip()]
       #["3","2","4","5","6","7"]=[3,2,4,5,6,7]
       smallest=numbers[0] # 2
       largest=numbers[0] #7
       for num in numbers:
           if num<smallest: # 7<2
               smallest=num#2
           if num>largest: # 7>6
               largest=num#7
    return render(request,'array.html',{'smallest':smallest,'largest':largest})

def array_push(request):
    return render(request, 'push.html')




   



    


   
      
      
    
   
        
    
        
    
        

    
    