from django.contrib import admin
from result.models import Enquiry
class saveenquiry(admin.ModelAdmin):
    en=('name','email','phone')
admin.site.register(Enquiry,saveenquiry)

# Register your models here.
