from django.db import models

class Enquiry (models.Model):# datatype access--Model
   
    name=models.CharField(max_length=25)
    email=models.CharField(max_length=25)
    phone=models.CharField(max_length=10)
